class Config:

    VERSIONS_ALLOWED = ['1']
